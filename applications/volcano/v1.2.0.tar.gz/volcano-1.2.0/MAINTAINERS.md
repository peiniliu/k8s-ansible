# Volcano Maintainers

## Current

| Maintainer           | GitHub ID                                               | Affiliation |
| -------------------- | ------------------------------------------------------- | ----------- |
| Klaus Ma             | [k82cn](https://github.com/k82cn)                       | Huawei      |
| Kevin Wang           | [kevin-wangzefeng](https://github.com/kevin-wangzefeng) | Huawei      |
| Zhonghu Xu           | [hzxuzhonghu](https://github.com/hzxuzhonghu)           | Huawei      |


## Emeritus

| Maintainer           | GitHub ID                                         | Affiliation |
| -------------------- | ------------------------------------------------- | ----------- |
| Quinton Hoole        | [quinton-hoole](https://github.com/quinton-hoole) | Facebook    |
| Animesh Singh        | [animeshsingh](https://github.com/animeshsingh)   | IBM         |
| Jun Gong             | [hex108](https://github.com/hex108)               | Tencent     |
