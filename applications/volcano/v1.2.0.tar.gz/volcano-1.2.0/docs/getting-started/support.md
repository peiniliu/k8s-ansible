
# Support

If you need support, start with the [troubleshooting guide](../troubleshooting/troubleshooting.md), and work your way through the process that we've outlined.

## Community

**Slack channel:**

We use Slack for public discussions. To chat with us or the rest of the community, join us in the [Volcano Slack](https://volcano-sh.slack.com) team channel #general. To sign up, use our Slack inviter link [here](https://join.slack.com/t/volcano-sh/shared_invite/enQtNTU5NTU3NDU0MTc4LTgzZTQ2MzViNTFmNDg1ZGUyMzcwNjgxZGQ1ZDdhOGE3Mzg1Y2NkZjk1MDJlZTZhZWU5MDg2MWJhMzI3Mjg3ZTk).

**Mailing List**

Please sign up on our [mailing list](https://groups.google.com/forum/#!forum/volcano-sh)
